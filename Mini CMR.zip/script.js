
const API = 'http://localhost:5000/api/leads';

async function loadLeads(){
  const res = await fetch(API);
  const data = await res.json();
  const list = document.getElementById('list');
  list.innerHTML = '';
  data.forEach(l => {
    const li = document.createElement('li');
    li.innerHTML = `${l.name} - ${l.status} 
      <button onclick="deleteLead('${l._id}')">Delete</button>`;
    list.appendChild(li);
  });
}

async function addLead(){
  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const source = document.getElementById('source').value;

  await fetch(API, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({name,email,source})
  });

  loadLeads();
}

async function deleteLead(id){
  await fetch(API + '/' + id, {method:'DELETE'});
  loadLeads();
}

loadLeads();
