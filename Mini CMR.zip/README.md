
# Mini CRM

## Run Backend
cd server
npm install
npm start

## Run Frontend
Open client/index.html in browser

## Features
- Add leads
- View leads
- Delete leads
